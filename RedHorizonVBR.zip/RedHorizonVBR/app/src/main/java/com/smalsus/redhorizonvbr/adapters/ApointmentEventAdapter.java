package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.model.EventInfo;
import com.smalsus.redhorizonvbr.utils.CalenderUtils;

import java.util.ArrayList;
import java.util.List;

public class ApointmentEventAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflter;
    List<EventInfo> eventList;
    AcustomButtonListener customListner;

    public ApointmentEventAdapter(Context context, ArrayList<EventInfo> eventDetail) {
        this.context = context;
        this.eventList = eventDetail;
        inflter = (LayoutInflater.from(context));
    }

    public interface AcustomButtonListener {
        void apointonButtonClickListner(ArrayList<String> videolIDist, int id, List<EventInfo> details, int position);
    }

    public void setCustomButtonListner(AcustomButtonListener listener) {
        this.customListner = listener;
    }

    @Override
    public int getCount() {
        return eventList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.profile_item, null);
        TextView eventName = view.findViewById(R.id.eventName);
        TextView agendatext = view.findViewById(R.id.agendatext);
        TextView no_of_participants = view.findViewById(R.id.no_of_participants);
        TextView meeting_time = view.findViewById(R.id.meeting_time);
        ImageButton call_btn = view.findViewById(R.id.call_btn);
        ImageButton vbr_btn = view.findViewById(R.id.vbr_btn);
        ImageView location_image = view.findViewById(R.id.location_image);
        LinearLayout mainlayout = view.findViewById(R.id.mainlayout_profile);
        no_of_participants.setText(String.valueOf(eventList.get(i).getMembers().size()));
        TextView eventBy=view.findViewById(R.id.eventBy);
        eventBy.setText(String.format("by %s", eventList.get(i).getfName()));
        agendatext.setText(eventList.get(i).getDesc());
        if (eventList.get(i).getLocation() != null) {
            if (eventList.get(i).getLocation().equalsIgnoreCase("skype")) {
                location_image.setImageResource(R.drawable.skype);
            } else {
                location_image.setImageResource(R.drawable.locationhr);
            }
        }


        mainlayout.setOnClickListener(view1 -> {
            if (customListner != null) {
                ArrayList<String> videolIDist = new ArrayList<>();
                for (int a = 0; a < eventList.get(i).getMembers().size(); a++) {
                  String  videoIDv = eventList.get(i).getMembers().get(a).getVideoId();
                    videolIDist.add(videoIDv);
                }
                customListner.apointonButtonClickListner(videolIDist, 2, eventList, i);
            }
        });


        vbr_btn.setOnClickListener(view12 -> {
            if (customListner != null) {
                ArrayList<String> videolIDist = new ArrayList<>();
                for (int a = 0; a < eventList.get(i).getMembers().size(); a++) {
                   String videoIDv = eventList.get(i).getMembers().get(a).getVideoId();
                    videolIDist.add(videoIDv);
                }
                customListner.apointonButtonClickListner(videolIDist, 3, eventList, i);
            }
        });


        call_btn.setOnClickListener(view13 -> {
            if (customListner != null) {
                String videoIDv = null;
                ArrayList<String> videolIDist = new ArrayList<>();
                for (int a = 0; a < eventList.get(i).getMembers().size(); a++) {
                    videoIDv = eventList.get(i).getMembers().get(a).getVideoId();
                    videolIDist.add(videoIDv);
                }
                customListner.apointonButtonClickListner(videolIDist, 1, eventList, i);
            }
        });

        eventName.setText(eventList.get(i).getEventName());
        if(eventList.get(i).getStartDate().length()>16 && eventList.get(i).getEndDate().length()>16){
            String starttime = eventList.get(i).getStartDate();
            String endtime = eventList.get(i).getEndDate();
            String meetingTime=String.format("%s TO %s", CalenderUtils.convertTimeDateFormat(starttime),CalenderUtils.convertTimeDateFormat(endtime));
            meeting_time.setText(meetingTime);
        }
        return view;
    }



}
