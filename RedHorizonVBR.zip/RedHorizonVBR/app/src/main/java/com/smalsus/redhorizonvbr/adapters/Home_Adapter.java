package com.smalsus.redhorizonvbr.adapters;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.smalsus.redhorizonvbr.view.fragments.ContactGroupFragment;
import com.smalsus.redhorizonvbr.view.fragments.DashboardFragment;
import com.smalsus.redhorizonvbr.view.fragments.Event_Fragment;
import com.smalsus.redhorizonvbr.view.fragments.Notification_fragment;
import com.smalsus.redhorizonvbr.view.fragments.Profile_user;

public class Home_Adapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    public Home_Adapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                DashboardFragment tab1 = new DashboardFragment();
                return tab1;
            case 1:
                Event_Fragment tab2 = new Event_Fragment();
                return tab2;
            case 2:
                Profile_user tab3 = new Profile_user();
                return tab3;
            case 3:
                Notification_fragment tab4= new Notification_fragment();
                return tab4;
            case 4:
                ContactGroupFragment tab5= new ContactGroupFragment();
                return tab5;
            default:
                return null;
        }
    }
    @Override
    public int getCount() {
        return mNumOfTabs;
    }

}
