package com.smalsus.redhorizonvbr.view.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smalsus.redhorizonvbr.HRpreference;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.model.UserInfo;
import com.smalsus.redhorizonvbr.networkrequest.EventRequest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class SplashScreen extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 5000;
    private static final String TAG = "SplashActivity";
    private static final int REQUEST = 112;
    private List<String> wantedPermissions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        FirebaseInstanceId.getInstance().getInstanceId()
//                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
//                        if (!task.isSuccessful()) {
//                            Log.w(TAG, "getInstanceId failed", task.getException());
//                            goToNextActivity();
//                            return;
//                        }
//                        String token = task.getResult().getToken();
//                        String msg = getString(R.string.fcm_token, token);
//                        goToNextActivity();
//                    }
//                });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (HRpreference.getInstance(getApplicationContext()).getUserInfo() == null)
                checkAndRequestPermissions();
            else
                checkLoginStatus();
        } else {
            checkLoginStatus();
        }

    }

    private void checkLoginStatus() {
        if (HRpreference.getInstance(getApplicationContext()).getLoginStatus()) {
            getUserDetails(HRpreference.getInstance(getApplicationContext()).getUserInfo().getAuthToken());
        } else {
            goToNextActivity(1);
        }
    }


    private void goToNextActivity(int activityType) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i;
                if (activityType == 2)
                    i = new Intent(SplashScreen.this, HomeScreen.class);
                else
                    i = new Intent(SplashScreen.this, LoginScreen.class);
                startActivity(i);
                finish();
            }
        }, SPLASH_TIME_OUT);
    }

    private void getUserDetails(String token) {
        EventRequest request = new EventRequest();
        request.getUserDetails(token, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        goToNextActivity(1);
                    }
                });

            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                final String myResponse = response.body().string();
                final int statusCode = response.code();
                if (statusCode == 200) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Gson gson = new GsonBuilder().create();
                            UserInfo form = gson.fromJson(myResponse, UserInfo.class);
                            HRpreference.getInstance(getApplicationContext()).saveUserInfo(form);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    goToNextActivity(2);
                                }
                            });
                        }
                    });
                } else if (statusCode == 401) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            disconnectFromFacebook();
                            goToNextActivity(1);
                        }
                    });
                }
            }
        });

    }

    public void disconnectFromFacebook() {

        if (AccessToken.getCurrentAccessToken() == null) {
            return;
        }

        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE, new GraphRequest
                .Callback() {
            @Override
            public void onCompleted(GraphResponse graphResponse) {

                LoginManager.getInstance().logOut();

            }
        }).executeAsync();
    }


    @TargetApi(Build.VERSION_CODES.M)
    private void checkAndRequestPermissions() {
        if (wantedPermissions.size() > 0)
            wantedPermissions.clear();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
            wantedPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
            wantedPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED)
            wantedPermissions.add(Manifest.permission.RECORD_AUDIO);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED)
            wantedPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!wantedPermissions.isEmpty())
            ActivityCompat.requestPermissions(this, wantedPermissions.toArray(new String[wantedPermissions.size()]), REQUEST);
        else
            checkLoginStatus();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST: {
                if (grantResults.length > 0)
                    checkAllPermissionGranted(grantResults);
            }
        }
    }

    private void checkAllPermissionGranted(@NonNull int[] grantResults) {
        int i = 0;
        for (int a = 0; a < grantResults.length; a++) {
            if (grantResults[a] == PackageManager.PERMISSION_GRANTED)
                i++;
        }
        if (i == wantedPermissions.size()) {
            checkLoginStatus();
        } else {
            checkAndRequestPermissions();
        }

    }
}
