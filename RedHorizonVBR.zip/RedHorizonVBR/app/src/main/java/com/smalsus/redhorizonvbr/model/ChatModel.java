package com.smalsus.redhorizonvbr.model;

import com.google.gson.annotations.SerializedName;

public class ChatModel {
    @SerializedName("id")
    String id;
    @SerializedName("text")
    String text;
    @SerializedName("by")
    EventUser Chatby;
    @SerializedName("to")
    String chatTO;
    @SerializedName("isGroupChat")
    Boolean isGroupChat;
    @SerializedName("at")
    String  at;


    public ChatModel (){

    }

    public ChatModel(String id, String text, EventUser chatby, String chatTO, Boolean isGroupChat, String at) {
        this.id = id;
        this.text = text;
        Chatby = chatby;
        this.chatTO = chatTO;
        this.isGroupChat = isGroupChat;
        this.at = at;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public EventUser getChatby() {
        return Chatby;
    }

    public void setChatby(EventUser chatby) {
        Chatby = chatby;
    }

    public String getChatTO() {
        return chatTO;
    }

    public void setChatTO(String chatTO) {
        this.chatTO = chatTO;
    }

    public Boolean getGroupChat() {
        return isGroupChat;
    }

    public void setGroupChat(Boolean groupChat) {
        isGroupChat = groupChat;
    }

    public String getAt() {
        return at;
    }

    public void setAt(String at) {
        this.at = at;
    }


}
