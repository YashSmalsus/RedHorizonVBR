package com.smalsus.redhorizonvbr.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;
import androidx.paging.LivePagedListBuilder;
import androidx.paging.PagedList;

import com.smalsus.redhorizonvbr.datasource.factory.FeedDataFactory;
import com.smalsus.redhorizonvbr.model.NetworkState;
import com.smalsus.redhorizonvbr.model.WerableStorePlaces;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class LocationViewModel extends ViewModel {

    private LiveData<NetworkState> networkState;
    private LiveData<PagedList<WerableStorePlaces>> heroList;


    public LocationViewModel() {
        init();
    }


    private void init() {
        Executor executor = Executors.newFixedThreadPool(5);

        FeedDataFactory feedDataFactory = new FeedDataFactory();
        networkState = Transformations.switchMap(feedDataFactory.getMutableLiveData(),
                dataSource -> dataSource.getNetworkState());

        PagedList.Config pagedListConfig =
                (new PagedList.Config.Builder())
                        .setEnablePlaceholders(false)
                        .setPageSize(20).build();

        heroList = (new LivePagedListBuilder(feedDataFactory, pagedListConfig))
                .setFetchExecutor(executor)
                .build();
    }

    public LiveData<NetworkState> getNetworkState() {
        return networkState;
    }

    public LiveData<PagedList<WerableStorePlaces>> getArticleLiveData() {
        return heroList;
    }

}
