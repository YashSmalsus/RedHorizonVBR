package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.interfaces.CustomButtonListener;
import com.smalsus.redhorizonvbr.model.GetEvent;
import com.smalsus.redhorizonvbr.utils.CalenderUtils;

import java.util.ArrayList;
import java.util.List;

public class PopupEventAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflter;
    private List<GetEvent> eventList;
    private CustomButtonListener customListner;

    public PopupEventAdapter(Context context, List<GetEvent> eventDetail) {
        this.context = context;
        this.eventList = eventDetail;
        inflter = (LayoutInflater.from(context));
    }

    public interface customButtonListener {
        void onButtonClickListner(ArrayList<String> videolIDist, int id, List<GetEvent> details, int position);
    }

    public void setCustomButtonListner(CustomButtonListener listener) {
        this.customListner = listener;
    }

    @Override
    public int getCount() {
        return eventList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.profile_item, null);
        TextView eventName = view.findViewById(R.id.eventName);
        TextView agendatext = view.findViewById(R.id.agendatext);
        TextView no_of_participants = view.findViewById(R.id.no_of_participants);
        TextView meeting_time = view.findViewById(R.id.meeting_time);
        ImageButton call_btn = view.findViewById(R.id.call_btn);
        ImageView location_image = view.findViewById(R.id.location_image);
        LinearLayout mainlayout = view.findViewById(R.id.mainlayout_profile);
        ImageButton vbr_btn = view.findViewById(R.id.vbr_btn);
        TextView eventBy = view.findViewById(R.id.eventBy);
        eventBy.setText(String.format("by %s", eventList.get(i).getEventUser().getfName()));
        no_of_participants.setText(String.valueOf(eventList.get(i).getEventmember().size()));
        if (eventList.get(i).getLocation() != null) {
            if (eventList.get(i).getLocation().equalsIgnoreCase("skype")) {
                location_image.setImageResource(R.drawable.skype);
            } else {
                location_image.setImageResource(R.drawable.locationhr);

            }
        }
        vbr_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (customListner != null) {
                    ArrayList<String> videolIDist = new ArrayList<>();
                    for (int a = 0; a < eventList.get(i).getEventmember().size(); a++) {
                        String videoIDv = eventList.get(i).getEventmember().get(a).getVideoId();
                        videolIDist.add(videoIDv);
                    }
                    customListner.onButtonClickListner(videolIDist, 3, eventList.get(i));
                }
            }
        });
        mainlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (customListner != null) {
                    ArrayList<String> videolIDist = new ArrayList<>();
                    for (int a = 0; a < eventList.get(i).getEventmember().size(); a++) {
                        String videoIDv = eventList.get(i).getEventmember().get(a).getVideoId();
                        videolIDist.add(videoIDv);
                    }
                    customListner.onButtonClickListner(videolIDist, 2, eventList.get(i));
                }
            }
        });
        agendatext.setText(String.format("%s...", eventList.get(i).getDesc()));
        eventName.setText(eventList.get(i).getName());
        if (eventList.get(i).getStartDate().length() > 16 && eventList.get(i).getEndDate().length() > 16) {
            String starttime = eventList.get(i).getStartDate();
            String endtime = eventList.get(i).getEndDate();
            String meetingTime = String.format("%s TO %s", CalenderUtils.convertTimeDateFormat(starttime), CalenderUtils.convertTimeDateFormat(endtime));
            meeting_time.setText(meetingTime);
        }

        return view;
    }

}
