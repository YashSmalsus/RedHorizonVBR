package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.smalsus.redhorizonvbr.model.ChatModel;

import java.util.List;

public class MessageAdapter  extends BaseAdapter {

    private Context context;
    private List<ChatModel>message;


    public  MessageAdapter(Context context , List<ChatModel>message){

        this.context=context;
        this.message=message;

    }


    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View convertView =view;

//        LayoutInflater messageInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
//
//        if (message.isBelongsToCurrentUser()) { // this message was sent by us so let's create a basic chat bubble on the right
//            convertView = messageInflater.inflate(R.layout.chatitem, null);
//            convertView.setTag(holder);
//        } else { // this message was sent by someone else so let's create an advanced chat bubble on the left
//            convertView = messageInflater.inflate(R.layout.their_message, null);
//            convertView.setTag(holder);
//
//        }

        return convertView;
    }


    }

