package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.paging.PagedListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.smalsus.redhorizonvbr.APIConstance.HRConstant;
import com.smalsus.redhorizonvbr.GlideUtils;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.model.NetworkState;
import com.smalsus.redhorizonvbr.model.WerableStorePlaces;

import static com.smalsus.redhorizonvbr.model.WerableStorePlaces.DIFF_CALLBACK;

public class WearableListAdapter extends PagedListAdapter<WerableStorePlaces, RecyclerView.ViewHolder> {
    private Context mContext;
    private static final int TYPE_PROGRESS = 0;
    private static final int TYPE_ITEM = 1;
    private NetworkState networkState;



    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        if(viewType == TYPE_PROGRESS) {
           View view=layoutInflater.inflate(R.layout.network_progress_item,parent,false);
            return new NetworkStateItemViewHolder(view);

        } else {
            View view=layoutInflater.inflate(R.layout.near_me_item_layout,parent,false);
            return new MyViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if(holder instanceof MyViewHolder) {
            ((MyViewHolder)holder).bindTo(getItem(position));
        } else {
            ((NetworkStateItemViewHolder) holder).bindView(networkState);
        }


    }

    public WearableListAdapter(Context mContext) {
        super(DIFF_CALLBACK);
        this.mContext = mContext;
    }



    private boolean hasExtraRow() {
        if (networkState != null && networkState != NetworkState.LOADED) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (hasExtraRow() && position == getItemCount() - 1) {
            return TYPE_PROGRESS;
        } else {
            return TYPE_ITEM;
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView name, address, rating,resturantDistance;
        private ImageView storeImage;


        public MyViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            name = view.findViewById(R.id.resturantName);
            address = view.findViewById(R.id.restuantAddress);
            rating = view.findViewById(R.id.rating);
            resturantDistance=view.findViewById(R.id.resturantDistance);
            storeImage=(ImageView)view.findViewById(R.id.storeImage);
        }
        public void bindTo(WerableStorePlaces article) {
            name.setText(article.name);
            address.setText(article.vicinity);
            rating.setText(article.rating);
            if(article.locationPhoto!=null && article.locationPhoto.size()>0){
                GlideUtils.loadImage(mContext,getImageUrl(article.locationPhoto.get(0).photo_reference),storeImage,R.mipmap.ic_launcher,R.mipmap.ic_launcher);
            }
        }


        @Override
        public void onClick(View view) {


        }
    }

    public class NetworkStateItemViewHolder extends RecyclerView.ViewHolder {

        private ProgressBar loader;
        private TextView errorText;

        public NetworkStateItemViewHolder(View binding) {
            super(binding);
            loader=binding.findViewById(R.id.progress_bar);
            errorText=binding.findViewById(R.id.error_msg);
        }

        public void bindView(NetworkState networkState) {
            if (networkState != null && networkState.getStatus() == NetworkState.Status.RUNNING) {
                loader.setVisibility(View.VISIBLE);
            } else {
                loader.setVisibility(View.GONE);
            }

            if (networkState != null && networkState.getStatus() == NetworkState.Status.FAILED) {
                errorText.setVisibility(View.VISIBLE);
                errorText.setText(networkState.getMsg());
            } else {
                errorText.setVisibility(View.GONE);
            }
        }
    }

    public void setNetworkState(NetworkState newNetworkState) {
        NetworkState previousState = this.networkState;
        boolean previousExtraRow = hasExtraRow();
        this.networkState = newNetworkState;
        boolean newExtraRow = hasExtraRow();
        if (previousExtraRow != newExtraRow) {
            if (previousExtraRow) {
                notifyItemRemoved(getItemCount());
            } else {
                notifyItemInserted(getItemCount());
            }
        } else if (newExtraRow && previousState != newNetworkState) {
            notifyItemChanged(getItemCount() - 1);
        }
    }

    private String getImageUrl(String photoRefrenced){
        StringBuilder photoURl=new StringBuilder().append(HRConstant.GooglePhotos).append("maxwidth=200").append("&photoreference=").append(photoRefrenced).append("&key=").append(HRConstant.GOOGLE_API_KEY);

        return photoURl.toString();
    }



}
