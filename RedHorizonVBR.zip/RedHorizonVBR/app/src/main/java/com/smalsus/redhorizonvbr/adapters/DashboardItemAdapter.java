package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.smalsus.redhorizonvbr.R;

public class DashboardItemAdapter extends RecyclerView.Adapter<DashboardItemAdapter.ViewHolder> {

    private Context mainActivityContext;


//TODO(14): Create one constructor with three parameters which will passed from MainActivity class

    public DashboardItemAdapter(Context mainActivityContext) {
        this.mainActivityContext = mainActivityContext;

    }

//TODO(15): Complete each method as mentioned below


    @Override
    public DashboardItemAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //Used to connect our custom UI to our recycler view

        View v = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.dashboard_grid_item, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(DashboardItemAdapter.ViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        //Returns total number of rows inside recycler view

        return 16;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        public ViewHolder(View itemView) {
            super(itemView);



        }
    }
}