package com.smalsus.redhorizonvbr;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.smalsus.redhorizonvbr.model.UserInfo;

public class HRpreference {
    private static HRpreference HRpreference;
    private SharedPreferences sharedPreferences;
    public static final String HR_PREFRENCE_NAME = "HR_PREFRENCE_NAME";
    private static final String USER_DATA_KEY = "user_data_key";
    private static final  String IS_LOGGED_IN_KEY="IS_LOGGED_IN_KEY";
    public static HRpreference getInstance(Context context) {
        if (HRpreference == null) {
            HRpreference = new HRpreference(context);
        }
        return HRpreference;
    }

    private HRpreference(Context context) {
        sharedPreferences = context.getSharedPreferences(HR_PREFRENCE_NAME, Context.MODE_PRIVATE);
    }
    public void saveUserInfo(UserInfo form) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(form);
        prefsEditor.putString(USER_DATA_KEY, json);
        prefsEditor.commit();
    }

    public UserInfo getUserInfo() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(USER_DATA_KEY, "");
        return gson.fromJson(json, UserInfo.class);
    }
    public void saveLoginStatus(boolean value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putBoolean(IS_LOGGED_IN_KEY, value);
        prefsEditor.commit();
    }

    public boolean getLoginStatus() {
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean(IS_LOGGED_IN_KEY, false);
        }
        return false;
    }
}
