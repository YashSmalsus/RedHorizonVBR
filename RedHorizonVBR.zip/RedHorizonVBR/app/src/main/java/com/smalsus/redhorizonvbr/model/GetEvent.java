package com.smalsus.redhorizonvbr.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class GetEvent implements Serializable {
    @SerializedName("id")
    String eventID;
    @SerializedName("name")
    String name;
    @SerializedName("startDate")
    String startDate;
    @SerializedName("endDate")
    String endDate;
    @SerializedName("createdAt")
    String createdAt;
    @SerializedName("availability")
    Integer availability;
    @SerializedName("location")
    String location;
    @SerializedName("reminder")
    String reminder;
    @SerializedName("isAllDay")
    Boolean isAllDay;
    @SerializedName("isPrivate")
    Boolean isPrivate;
    @SerializedName("desc")
    String desc;
    @SerializedName("isActive")
    Boolean isActive;
    @SerializedName("by")
    EventUser eventUser;
    @SerializedName("members")
    List<EventUser> eventmember;

    public GetEvent(String name, String startDate, String endDate, String createdAt, Integer availability, String location, String reminder, Boolean isAllDay, Boolean isPrivate, String desc, Boolean isActive, EventUser eventUser, List<EventUser> eventmember) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.createdAt = createdAt;
        this.availability = availability;
        this.location = location;
        this.reminder = reminder;
        this.isAllDay = isAllDay;
        this.isPrivate = isPrivate;
        this.desc = desc;
        this.isActive = isActive;
        this.eventUser = eventUser;
        this.eventmember = eventmember;
    }

    public String getEventID() {
        return eventID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getAvailability() {
        return availability;
    }

    public void setAvailability(Integer availability) {
        this.availability = availability;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getReminder() {
        return reminder;
    }

    public void setReminder(String reminder) {
        this.reminder = reminder;
    }

    public Boolean getAllDay() {
        return isAllDay;
    }

    public void setAllDay(Boolean allDay) {
        isAllDay = allDay;
    }

    public Boolean getPrivate() {
        return isPrivate;
    }

    public void setPrivate(Boolean aPrivate) {
        isPrivate = aPrivate;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public EventUser getEventUser() {
        return eventUser;
    }

    public void setEventUser(EventUser eventUser) {
        this.eventUser = eventUser;
    }

    public List<EventUser> getEventmember() {
        return eventmember;
    }

    public void setEventmember(List<EventUser> eventmember) {
        this.eventmember = eventmember;
    }
}
