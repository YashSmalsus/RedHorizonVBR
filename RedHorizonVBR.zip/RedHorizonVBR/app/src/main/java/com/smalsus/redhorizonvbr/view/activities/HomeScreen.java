package com.smalsus.redhorizonvbr.view.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.smalsus.redhorizonvbr.R;


public class HomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
    }
}
