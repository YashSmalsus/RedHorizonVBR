package com.smalsus.redhorizonvbr.model;

import java.util.ArrayList;

public class CalenderEventForm {


    public String daytoDisplay;
    public int dateToDisplay;
    public ArrayList<EventInfo> eventList;
    public int isDateBiggerThenCurrent;

    public CalenderEventForm(String daytoDisplay, int dateToDisplay, ArrayList<EventInfo> eventList, int isDateBiggerThenCurrent) {
        this.daytoDisplay = daytoDisplay;
        this.dateToDisplay = dateToDisplay;
        this.eventList = eventList;
        this.isDateBiggerThenCurrent = isDateBiggerThenCurrent;
    }

    public CalenderEventForm() {

    }

    public String getDaytoDisplay() {
        return daytoDisplay;
    }

    public void setDaytoDisplay(String daytoDisplay) {
        this.daytoDisplay = daytoDisplay;
    }

    public int getDateToDisplay() {
        return dateToDisplay;
    }

    public void setDateToDisplay(int dateToDisplay) {
        this.dateToDisplay = dateToDisplay;
    }

    public ArrayList<EventInfo> getEventList() {
        return eventList;
    }

    public void setEventList(ArrayList<EventInfo> eventList) {
        this.eventList = eventList;
    }

    public int getDateBiggerThenCurrent() {
        return isDateBiggerThenCurrent;
    }

    public void setDateBiggerThenCurrent(int dateBiggerThenCurrent) {
        isDateBiggerThenCurrent = dateBiggerThenCurrent;
    }

}
