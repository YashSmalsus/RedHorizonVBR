package com.smalsus.redhorizonvbr.interfaces;


public interface OnCallEventsController {

    void onUseHeadSet(boolean use);
}