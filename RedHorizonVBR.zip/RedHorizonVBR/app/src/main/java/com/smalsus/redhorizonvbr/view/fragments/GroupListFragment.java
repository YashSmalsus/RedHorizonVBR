package com.smalsus.redhorizonvbr.view.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.smalsus.redhorizonvbr.HRpreference;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.adapters.GrouplistAdapter;
import com.smalsus.redhorizonvbr.model.EventUser;
import com.smalsus.redhorizonvbr.model.GroupModel;
import com.smalsus.redhorizonvbr.model.UpdateGroupListEvent;
import com.smalsus.redhorizonvbr.model.UserInfo;
import com.smalsus.redhorizonvbr.viewmodel.GroupListViewModel;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.util.ArrayList;
import java.util.List;

public class GroupListFragment extends Fragment implements GrouplistAdapter.ItemClickListener {
    private ProgressDialog dialog;
    private List<GroupModel> groupList;
    private GrouplistAdapter grouplistAdapter;
    private OnFragmentInteractionListener mListener;
    public static boolean isRefresh = false;
    private GroupListViewModel groupListViewModel;

    public GroupListFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static GroupListFragment newInstance() {
        GroupListFragment fragment = new GroupListFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        groupList = new ArrayList<>();
        dialog = new ProgressDialog(getContext());

    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_group_list, container, false);
        RecyclerView grouplist = view.findViewById(R.id.grouplist);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        grouplist.setLayoutManager(mLayoutManager);
        grouplistAdapter = new GrouplistAdapter(getContext(), groupList);
        grouplist.setAdapter(grouplistAdapter);
        grouplistAdapter.setClickListener(GroupListFragment.this);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed() {
        if (mListener != null) {
            //  mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        groupListViewModel = ViewModelProviders.of(this).get(GroupListViewModel.class);
        UserInfo userInfo = HRpreference.getInstance(getContext()).getUserInfo();
        groupListViewModel.getGroup(userInfo.getId(), userInfo.getAuthToken()).observe(this, groupModels -> grouplistAdapter.setDatalist(groupModels));
    }

    @Override
    public void onAttach(@NotNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isRefresh) {
            UserInfo userInfo = HRpreference.getInstance(getContext()).getUserInfo();
            groupListViewModel.getGroupList(userInfo.getId(), userInfo.getAuthToken());
            isRefresh = false;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(UpdateGroupListEvent event) {
        UserInfo userInfo = HRpreference.getInstance(getContext()).getUserInfo();
        groupListViewModel.getGroupList(userInfo.getId(), userInfo.getAuthToken());
        Toast.makeText(getContext(), event.message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemClick(int position) {
        showDetails(position);
    }

    private void showDetails(int id) {
        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(getContext());
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.grouplistdetails, null);
        TextView groupname = dialogView.findViewById(R.id.group_name);
        TextView groupAdmin = dialogView.findViewById(R.id.group_admin);
        TextView groupmember = dialogView.findViewById(R.id.member_group);
        Button call_btn = dialogView.findViewById(R.id.call_group_btn);
        groupname.setText(groupList.get(id).getName());
        groupAdmin.setText(groupList.get(id).getEventUser().getfName());
        StringBuilder membersname = new StringBuilder();
        for (int i = 0; i < groupList.get(id).getEventmember().size(); i++) {
            if (i < groupList.get(id).getEventmember().size() - 1) {
                membersname.append(groupList.get(id).getEventmember().get(i).getfName()).append(" ,");
            } else {
                membersname.append(groupList.get(id).getEventmember().get(i).getfName()).append(" ");
            }
        }
        groupmember.setText(membersname.toString());
        dialogBuilder.setView(dialogView);
        android.app.AlertDialog alertDialog = dialogBuilder.create();
        call_btn.setOnClickListener(view -> {
            ArrayList<String> videolIDist = new ArrayList<>();
            for (int i = 0; i < groupList.get(id).getEventmember().size(); i++) {
                String videoIDv = groupList.get(id).getEventmember().get(i).getVideoId();
                videolIDist.add(videoIDv);
            }
            if (videolIDist.size() > 0) {
                mListener.onFragmentInteraction(5, false, false, videolIDist, groupList.get(id).getEventmember());
                alertDialog.dismiss();
            }

        });
        alertDialog.show();
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(int screntType, boolean isVIDEO, boolean isVBR, ArrayList<String> userIDs, List<EventUser> eventmember);
    }

}
