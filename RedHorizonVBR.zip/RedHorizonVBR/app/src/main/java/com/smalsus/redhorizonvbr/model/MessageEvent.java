package com.smalsus.redhorizonvbr.model;

public class MessageEvent {
    public final String message;
    public MessageEvent(String message) {
        this.message = message;
    }
}
