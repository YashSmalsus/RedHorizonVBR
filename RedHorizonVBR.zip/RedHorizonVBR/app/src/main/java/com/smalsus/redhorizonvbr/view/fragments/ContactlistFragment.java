package com.smalsus.redhorizonvbr.view.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.smalsus.redhorizonvbr.GlideUtils;
import com.smalsus.redhorizonvbr.HRpreference;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.adapters.FriendListAdapter;
import com.smalsus.redhorizonvbr.model.EventUser;
import com.smalsus.redhorizonvbr.model.Userlist;
import com.smalsus.redhorizonvbr.view.activities.CreateGroup;
import com.smalsus.redhorizonvbr.view.activities.InviteFriendLIstScreen;
import com.smalsus.redhorizonvbr.viewmodel.ContactListViewModel;

import java.util.ArrayList;
import java.util.List;

public class ContactlistFragment extends Fragment implements View.OnClickListener, FriendListAdapter.ItemClickListener {
    private ProgressDialog dialog;
    private RecyclerView userlist;
    private List<Userlist> contactList;
    private Button creategroup, invitefriend;
    private OnFragmentInteractionListener mListener;
    private List<EventUser> friendlist;
    private FriendListAdapter friendListAdapter;

    public ContactlistFragment() {

    }

    public static ContactlistFragment newInstance(String param1, String param2) {
        ContactlistFragment fragment = new ContactlistFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        friendlist = new ArrayList<>();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contactlist, container, false);
        userlist = view.findViewById(R.id.contactList);
        creategroup = view.findViewById(R.id.creategroup);
        creategroup.setOnClickListener(this);
        invitefriend = view.findViewById(R.id.invitefriend);
        invitefriend.setOnClickListener(this);
        dialog = new ProgressDialog(getContext());
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        userlist.setLayoutManager(mLayoutManager);
        friendListAdapter = new FriendListAdapter(getActivity(), friendlist);
        userlist.setAdapter(friendListAdapter);
        friendListAdapter.setClickListener(this);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
          //  mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ContactListViewModel contactListViewModel= ViewModelProviders.of(this).get(ContactListViewModel.class);
        contactListViewModel.getUsers(HRpreference.getInstance(getContext()).getUserInfo().getId(), HRpreference.getInstance(getContext()).getUserInfo().getAuthToken()).observe(this, new Observer<List<EventUser>>() {
            @Override
            public void onChanged(List<EventUser> eventUsers) {
                friendlist.addAll(eventUsers);
                friendListAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View view) {
        if (view == creategroup) {
            Intent intent = new Intent(getContext(), CreateGroup.class);
            startActivity(intent);
        } else if (view == invitefriend) {
            Intent intent = new Intent(getContext(), InviteFriendLIstScreen.class);
            startActivity(intent);
        }

    }

    @Override
    public void onItemClick(String userID,String name, String videoID, int id, String imageurl) {
        if (id == 1) {
            showConfirmMessage(name, videoID);
        } else if (id == 2) {
            showDetails(name, videoID, imageurl);
        }

    }
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(int screntType, boolean isVIDEO, boolean isVBR, ArrayList<String> userIDs, List<EventUser> eventmember);
    }


    private void showConfirmMessage(String name, String videoID) {
        ArrayList<String> idsList=new ArrayList<>();
        idsList.add(videoID);
        AlertDialog.Builder builder1 = new AlertDialog.Builder(getContext());
        builder1.setMessage("Do you  want to call to " + name);
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                "Confirm",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                      mListener.onFragmentInteraction(4,false,false,idsList,null);
                        dialog.cancel();
                    }
                });
        builder1.setNegativeButton(
                "Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    public void showDetails(String name, String videoID, String imageurl) {
        ArrayList<String> idsList=new ArrayList<>();
        idsList.add(videoID);
        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(getContext());
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.friendprofile, null);
        TextView friend_name = dialogView.findViewById(R.id.friendname);
        ImageView image = dialogView.findViewById(R.id.friendimage);
        Button callbtn = dialogView.findViewById(R.id.callbtn);
        friend_name.setText(name);
        GlideUtils.loadImage(getContext(), imageurl, image, R.mipmap.ic_launcher, R.mipmap.ic_launcher);
        dialogBuilder.setView(dialogView);
        android.app.AlertDialog alertDialog = dialogBuilder.create();
        callbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onFragmentInteraction(4,false,false,idsList,null);
                alertDialog.dismiss();
            }
        });

        alertDialog.show();
    }


}
