package com.smalsus.redhorizonvbr.APIConstance;

public class HRConstant {
    public static final String BASEURL="http://3.19.76.185:1211/";
    public static final String BaseURL = " http://3.19.76.185:1211/user/";
    public static final String loginURl = " http://3.19.76.185:1211/user/login";
    public static final String inviteURL="http://3.19.76.185:1211/user/invite";
    public static final String createUSer = " http://3.19.76.185:1211/user";
    public static final String getUserDetails="http://3.19.76.185:1211/user";
    public static final String IMAGE_UPLOAD_URL="http://renew360.com.wb7.my-hosting-panel.com/";

    public static final String USER_LATITUDE="lat";
    public static final String USER_LONGTITUDE="long";
    public static final String USER_COUNTRY_LOCATION="user_country";
    public static final String USER_CITY_LOCATION="user_city";

    public static final String TwallioBaseURL="https://api.twilio.com/2010-04-01/Accounts/";
    public static  final String GOOGLE_API_KEY=" AIzaSyDKsdpKzjLgxnPbckIKWNWn5Ax7-e3ADH8";
    public static final String NearBYGoogle="https://maps.googleapis.com/maps/api/place/nearbysearch/json?";
    public static final String GooglePhotos="https://maps.googleapis.com/maps/api/place/photo?";
    public static final int REQUEST_CHECK_SETTINGS=105;

}
