package com.smalsus.redhorizonvbr.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.smalsus.redhorizonvbr.GlideUtils;
import com.smalsus.redhorizonvbr.R;

import java.util.ArrayList;

public class Details_list extends BaseAdapter {
    private LayoutInflater inflter;
    private Context context;
    ArrayList<String> members_name;
    ArrayList<String> imageUrl;

    public Details_list(Context context, ArrayList<String> membersname, ArrayList<String> imageUrl) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.members_name=membersname;
        this.imageUrl=imageUrl;
    }
    @Override
    public int getCount() {
        return members_name.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.eventdetails_item, null);
        ImageView member_image=view.findViewById(R.id.image_member);
        TextView member_name=view.findViewById(R.id.member_name);
        member_name.setText(members_name.get(i));
        GlideUtils.loadImage(context,imageUrl.get(i), member_image, R.drawable.defaultuser, R.drawable.defaultuser);
        return view;
    }
}
