package com.smalsus.redhorizonvbr.view.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.smalsus.redhorizonvbr.R;


public class QrCodeTabFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private OnFragmentInteractionListener mListener;
    private ImageButton genrateBarcode;

    public QrCodeTabFragment() {
        // Required empty public constructor
    }


    public static QrCodeTabFragment newInstance() {
        QrCodeTabFragment fragment = new QrCodeTabFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_qr_code_tab, container, false);
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        ft.replace(R.id.qrcode_placeholder, new QrCodeScannerGenrator());
        ft.commit();
        ft.addToBackStack(null);
        genrateBarcode=view.findViewById(R.id.genrateBarcode);

        genrateBarcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = getChildFragmentManager().beginTransaction();
                ft.replace(R.id.qrcode_placeholder, new GenrateQrCodeFragment());
                ft.commit();
                ft.addToBackStack(null);
            }
        });

        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(@NotNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
