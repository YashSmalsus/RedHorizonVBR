package com.smalsus.redhorizonvbr.utils;

import android.content.Context;
import android.text.TextUtils;
import com.smalsus.redhorizonvbr.db.QbUsersDbManager;

import java.util.ArrayList;
import java.util.List;


public class UsersUtils {





}