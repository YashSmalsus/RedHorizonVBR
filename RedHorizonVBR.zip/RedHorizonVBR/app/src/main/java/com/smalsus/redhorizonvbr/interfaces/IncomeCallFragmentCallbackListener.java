package com.smalsus.redhorizonvbr.interfaces;


public interface IncomeCallFragmentCallbackListener {

    void onAcceptCurrentSession();

    void onRejectCurrentSession();
}