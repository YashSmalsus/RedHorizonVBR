package com.smalsus.redhorizonvbr.view.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.smalsus.redhorizonvbr.GlideUtils;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.adapters.Details_list;
import com.smalsus.redhorizonvbr.model.EventInfo;
import com.smalsus.redhorizonvbr.model.GetEvent;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventDetailScreen extends AppCompatActivity implements View.OnClickListener {
    private TextView eventName, eventDateTime, reminderEvent, adminEmail, eventMember, created_date, agenda;
    private ImageButton backbtn, editButton;
    private Intent intent;
    private String reminder, eventname, name;
    private Integer position;
    private GetEvent eventDetail;
    private ProgressDialog dialog;
    private Date date;
    private ListView list_member;
    private ArrayList<String> members_event;
    private ArrayList<String> imageList;
    private List<EventInfo> calenderEventList;
    private ImageView createdby_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail_screen);
        list_member = findViewById(R.id.list_member);
        dialog = new ProgressDialog(this);
        editButton = findViewById(R.id.edit_event);
        editButton.setOnClickListener(this);
        created_date = findViewById(R.id.created_date);
        agenda = findViewById(R.id.meeting_agenda);
        createdby_image = findViewById(R.id.create_image);
        intent = getIntent();
        members_event = new ArrayList<>();
        calenderEventList = new ArrayList<>();
        imageList = new ArrayList<>();
        backbtn = findViewById(R.id.cancel);
        backbtn.setOnClickListener(this);
        editButton = findViewById(R.id.edit_event);
        eventName = findViewById(R.id.event_name);
        eventDateTime = findViewById(R.id.event_date_time);
        reminderEvent = findViewById(R.id.reminder_time);
        adminEmail = findViewById(R.id.admin_emailID);
        eventMember = findViewById(R.id.event_member);
        position = intent.getIntExtra("position", 0);
        int screen = intent.getIntExtra("screen", 0);
        if (screen == 2) {
            calenderEventList = ((List<EventInfo>) getIntent().getExtras().getSerializable("EVENT_DETAILS"));
            if(calenderEventList!=null){
                eventName.setText(calenderEventList.get(position).getEventName());
                reminderEvent.setText(calenderEventList.get(position).getReminder() + " min");
                String[] createdDate = calenderEventList.get(position).getCreatedAt().split("T");
                String dat = createdDate[0];
                created_date.setText(dat);
                agenda.setText(calenderEventList.get(position).getDesc());
                adminEmail.setText(calenderEventList.get(position).getfName());
                String membersname = "";
                String imageUrl = "";
                for (int i = 0; i < calenderEventList.get(position).getMembers().size(); i++) {

                    imageUrl = calenderEventList.get(position).getMembers().get(i).getImageUrl();
                    membersname = calenderEventList.get(position).getMembers().get(i).getfName();
                    members_event.add(membersname);
                    imageList.add(imageUrl);
                }

                String starttime = calenderEventList.get(position).getStartDate().substring(11, 16);
                String[] startdate = calenderEventList.get(position).getStartDate().split("T");
                String date_event = startdate[0];
                String endtime = calenderEventList.get(position).getEndDate().substring(11, 16);
                eventDateTime.setText(date_event + " , " + parseTime(starttime) + " to " + parseTime(endtime));

                Details_list details_list = new Details_list(getApplicationContext(), members_event, imageList);
                list_member.setAdapter(details_list);
            }
        } else if (screen==1){
            eventDetail = (GetEvent) getIntent().getExtras().getSerializable("EVENT_DETAILS");
            if(eventDetail!=null){
                eventName.setText(eventDetail.getName());
                GlideUtils.loadImage(this, eventDetail.getEventUser().getImageUrl(), createdby_image, R.drawable.defaultuser, R.drawable.defaultuser);
                reminderEvent.setText(eventDetail.getReminder() + " min");
                adminEmail.setText(eventDetail.getEventUser().getfName());
                String starttime = eventDetail.getStartDate().substring(11, 16);
                String[] startdate = eventDetail.getStartDate().split("T");
                String date_event = startdate[0];
                String endtime = eventDetail.getEndDate().substring(11, 16);
                eventDateTime.setText(date_event + " , " + parseTime(starttime) + " to " + parseTime(endtime));
                for (int i = 0; i < eventDetail.getEventmember().size(); i++) {
                   String imageUrl = eventDetail.getEventmember().get(i).getImageUrl();
                   String membersname = eventDetail.getEventmember().get(i).getfName();
                    members_event.add(membersname);
                    imageList.add(imageUrl);
                }
                String[] createdDate = eventDetail.getCreatedAt().split("T");
                String dat = createdDate[0];
                created_date.setText(dat);
                agenda.setText(eventDetail.getDesc());
                Details_list details_list = new Details_list(getApplicationContext(), members_event, imageList);
                list_member.setAdapter(details_list);
            }

        }
    }

    public static String getCurrentDateTime() {
        String dateValue = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            dateValue = sdf.format(Calendar.getInstance().getTime());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return dateValue;
    }

    @Override
    public void onClick(View view) {
        if (view == backbtn) {
            finish();
        } else if (view == editButton) {
            Intent intent = new Intent(EventDetailScreen.this, AddEventScreen.class);
            intent.putExtra("EVENT_DETAILS", (Serializable) eventDetail);
            intent.putExtra("EVENT_LIST_POSITION",position);
            intent.putExtra("ISUPADTE_EVENT",true);
            startActivity(intent);

        }
    }

    public static String parseTime(String date) {
        try {
            Date date1 = new SimpleDateFormat("hh:mm", Locale.getDefault()).parse(date);
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm aa", Locale.getDefault());
            return dateFormat.format(date1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}

