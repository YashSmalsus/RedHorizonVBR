package com.smalsus.redhorizonvbr.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.smalsus.redhorizonvbr.GlideUtils;
import com.smalsus.redhorizonvbr.R;
import com.smalsus.redhorizonvbr.model.EventUser;
import com.smalsus.redhorizonvbr.model.UserLocation;

import java.util.List;

public class FriendListAdapter extends RecyclerView.Adapter<FriendListAdapter.ViewHolder> {
    private Activity context;
    private List<EventUser> list;
    private ItemClickListener mClickListener;

    public FriendListAdapter(Activity context, List<EventUser> list) {
        this.context = context;
        this.list = list;
    }

    @NotNull
    @Override
    public FriendListAdapter.ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.friendlist_item_layout, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull FriendListAdapter.ViewHolder holder, int position) {

        StringBuilder userName=new StringBuilder().append(list.get(position).getUserName()).append(" ").append(list.get(position).getlName());
        holder.username.setText(userName.toString());
        holder.userId.setText(list.get(position).getId());
        GlideUtils.loadImage(context, list.get(position).getImageUrl(), holder.userprofilepic, R.mipmap.ic_launcher, R.mipmap.ic_launcher);
        if(list.get(position).getLocationMap()!=null){
            UserLocation userLocation=list.get(position).getLocationMap();
            String userLocationText=(userLocation.getUserCity()!=null?userLocation.getUserCity():" ")+((userLocation.getUserCountry()!=null?", "+userLocation.getUserCountry():" "));
            holder.userLocation.setText(userLocationText);
        }
        holder.mainlayout.setOnLongClickListener(view -> {
                 if (mClickListener != null) mClickListener.onItemClick( list.get(position).getId(),list.get(position).getUserName(),list.get(position).getVideoId(),1,list.get(position).getImageUrl());
            return false;
        });
        holder.mainlayout.setOnClickListener(view -> {
            if (mClickListener != null) mClickListener.onItemClick( list.get(position).getId(),list.get(position).getUserName(),list.get(position).getVideoId(),2,list.get(position).getImageUrl());

        });
    }




    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView username,userId,userLocation;
        private View view;
        CheckBox checkbox;
        ImageView userprofilepic;
        RelativeLayout mainlayout;

        public ViewHolder(View itemView) {
            super(itemView);
            view = itemView;
            username = itemView.findViewById(R.id.username);
            userLocation=itemView.findViewById(R.id.userLocation);
            userId=itemView.findViewById(R.id.userID);
            checkbox = itemView.findViewById(R.id.checkbox);
            userprofilepic = itemView.findViewById(R.id.userprofilepic);
            mainlayout=itemView.findViewById(R.id.mainlayout);
        }
    }

    public String getItem(int id) {
        return list.get(id).getfName();
    }

    // allows clicks events to be caught
    public void setClickListener(FriendListAdapter.ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(String userID, String name, String videoID, int id, String imageurl);
    }

}