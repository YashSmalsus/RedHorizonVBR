package com.smalsus.redhorizonvbr.model;

public class UpdateGroupListEvent {
    public final String message;
    public UpdateGroupListEvent(String message) {
        this.message = message;
    }
}
