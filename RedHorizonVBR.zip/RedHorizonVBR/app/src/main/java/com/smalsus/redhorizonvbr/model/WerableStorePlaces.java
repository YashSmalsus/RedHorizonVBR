package com.smalsus.redhorizonvbr.model;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class WerableStorePlaces implements Serializable {

    @SerializedName("id")
    public String id;
    @SerializedName("geometry")
    public Geometry geometry;
    @SerializedName("vicinity")
    public String vicinity;
    @SerializedName("name")
    public String name;
    @SerializedName("rating")
    public String rating;
    @SerializedName("photos")
    public List<Photo> locationPhoto;


    public class Geometry implements Serializable {

        @SerializedName("location")
        public LocationA locationA;

    }

    public class LocationA implements Serializable {

        @SerializedName("lat")
        public String lat;
        @SerializedName("lng")
        public String lng;


    }

    public class Photo implements Serializable {
        @SerializedName("photo_reference")
        public String photo_reference;

    }

    public static DiffUtil.ItemCallback<WerableStorePlaces> DIFF_CALLBACK = new DiffUtil.ItemCallback<WerableStorePlaces>() {
        @Override
        public boolean areItemsTheSame(@NonNull WerableStorePlaces oldItem, @NonNull WerableStorePlaces newItem) {
            return oldItem.id.equals(newItem.id);
        }

        @Override
        public boolean areContentsTheSame(@NonNull WerableStorePlaces oldItem, @NonNull WerableStorePlaces newItem) {
            return oldItem.equals(newItem);
        }
    };

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;

        WerableStorePlaces article = (WerableStorePlaces) obj;
        return article.id.equals(this.id);
    }
}